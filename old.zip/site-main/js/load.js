$(function() {
    $("#header").load("header.html");
    $("#headers").load("headers.html");
    $("#footer").load("footer.html");
});