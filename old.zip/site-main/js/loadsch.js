$(function() {
    $("#sch").load("sch.html");
});